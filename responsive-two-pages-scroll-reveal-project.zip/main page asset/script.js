function _open_menu(){
    document.getElementsByClassName('sub_menu_2')[0].style.left = '0'
}
function _close_menu(){
    document.getElementsByClassName('sub_menu_2')[0].style.left = '-100%'
}

ScrollReveal({ 
    reset: false,
    distance:'60px',
    duration: 2500,
    delay: 400 
});

ScrollReveal().reveal('head_top, .logo, .picture, img', { delay: 500, origin: 'left' });
ScrollReveal().reveal('.main_menu, .nav_menu, .sub_nav_menu', { delay: 500, origin: 'right' });
ScrollReveal().reveal('.main_menu, .open_menu', { delay: 500, origin: 'right' });
ScrollReveal().reveal('.best_title', { delay: 450, origin: 'top' });
ScrollReveal().reveal('.shape1, .shape2', { delay: 550, origin: 'left' });
ScrollReveal().reveal('.picture2', { delay: 500, origin: 'bottom' });
ScrollReveal().reveal('.box, .sub_box', { delay: 500, origin: 'top' });
ScrollReveal().reveal('.box, .sub_box, figure', { delay: 550, origin: 'right' });
ScrollReveal().reveal('.box, h4', { delay: 560, origin: 'left' });
ScrollReveal().reveal('.box, p', { delay: 560, origin: 'right' });
