function _open_menu(){
    document.getElementsByClassName('sub_menu_2')[0].style.left = '0'
}
function _close_menu(){
    document.getElementsByClassName('sub_menu_2')[0].style.left = '-100%'
}

ScrollReveal({ 
    reset: false,
    distance:'60px',
    duration: 2500,
    delay: 400 
});

ScrollReveal().reveal('head_top, .logo, .picture, img', { delay: 500, origin: 'left' });
ScrollReveal().reveal('.main_menu, .nav_menu, .sub_nav_menu', { delay: 500, origin: 'right' });
ScrollReveal().reveal('.main_menu, .open_menu', { delay: 500, origin: 'right' });
ScrollReveal().reveal('.title, .line, .mytext1, .mytext2', { delay: 600, origin: 'right' });
